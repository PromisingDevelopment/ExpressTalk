export interface IUser {
  login: string;
  name: string;
  email: string;
  password: string;
}

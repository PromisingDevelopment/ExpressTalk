export interface EmailFields {
  code: string;
}

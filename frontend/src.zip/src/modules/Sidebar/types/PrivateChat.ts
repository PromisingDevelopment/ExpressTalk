export interface PrivateChat {
  id: string;
  receiverLogin: string;
  lastMessage: string;
}
